%
% plot null-clines for the two buffer system
%
%params = parameters2Buffer;
params = parameters2Buffer_trig_2buf_5;

p=0.4
nullClines2Buffer_v2( params, p );
