function nsteps=numberOfWaveSteps( ndim, q )

ncomp=6;
nsteps = size(q,1)/ncomp;
 
