//
// test virtual table stuff
//
#include <iostream>

class Base 
{
private:
  std::string          reactionName;
protected:
  void                 setReactionName( const std::string &name);
public:

  Base() { }; // do nothing
  ~Base() { }; // do nothing
    
  virtual void whoami()=0;
};

//void Base::whoami()
//{
//  std::cout <<"I am Base\n";
//}

class Specific : public Base 
{
public:
  virtual void whoami();
};

void Specific::whoami()
{
  std::cout << "I am Specific\n";
};

int main(int argc, char **argv)
{
  //Base base;
  //base.whoami();

  Base *pBase = new Specific();
  Base &base2 = *pBase;

  base2.whoami();

  return(0);
}
