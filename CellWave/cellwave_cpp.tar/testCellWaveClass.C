#include "CellWave.h"

int main(int argc, char **argv)
{
  CellWave::start( argc, argv);

  CellWave::finish();
}
