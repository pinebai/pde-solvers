#include "GenericReaction.h"

int main(int argc, char **argv)
{
  //CellWave::GenericReaction  chem;

}
