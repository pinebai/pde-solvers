/// Brief description: common code for Solver classes in CellWave
///
///
///



#include <assert.h>
#include "Overture.h"
#include "Ogshow.h"  
#include "CompositeGridOperators.h"

//#include "CellWave.h"
#include "GenericReaction.h"
#include "ReactionFactory.h"
#include "Info.h"
#include "getDiffusionDT.h"

#include "GenericSolver.h"

using namespace CellWave;

//.. virtual functions -- defined in derived classes
bool CellWave::GenericSolver::
readParameterFile( CellWave::ParameterReader &param)
{
  // do nothing
}


//.. Base class services

void GenericSolver::
genericSetup( GenericReaction *pChem_ )
{
  //CalciumChemistry chem(cg.numberOfDimensions());  // initializes parameters automatically (by constructor)
  pChem = pChem_;
  assert( pChem != NULL );
  CellWave::GenericReaction &chem = *pChem; // shorthand
 
  // create and read in a CompositeGrid
  //CompositeGrid cg;
  //aString nameOfGrid = data.nameOfOGFile.c_str();
  getFromADataBase( cg, data.nameOfOGFile.c_str() );
  cg.update();

  //Interpolant interpolant(cg);
  interpolant.updateToMatchGrid( cg );

  // ..create a show file
  // ..then save a general comment in the show file
  //Ogshow show( nameOfShowFile );                     
  show.open( data.nameOfShowFile.c_str() );
  show.saveGeneralComment("CellWave for Calcium wave modeling");
  show.setFlushFrequency(100);   
  operators.updateToMatchGrid( cg );
  
}

void GenericSolver::
updateModel()
{
  assert( pChem != NULL );
  CellWave::GenericReaction &chem = *pChem; // shorthand

  //....create grid functions
  Range all;
  q.updateToMatchGrid(cg,all,all,all,2* chem.getNumberOfSpecies());
  q.setOperators( operators );
  q.setName("all");              

  int numSpecies=chem.getNumberOfSpecies();
  std::string compName =chem.getTitle();
  printf("GenericSolver::updateModel-->%s\n", compName.c_str());
  q.setName( compName.c_str() );
  for (int j=0; j<numSpecies; ++j)  {
    compName = chem.getLongComponentName( j );
    q.setName( compName.c_str(), j);
  }

  f. updateToMatchGrid(cg,all,all,all,chem.getNumberOfSpecies()); 
  fp.updateToMatchGrid(cg,all,all,all,chem.getNumberOfSpecies());
};

void GenericSolver::
genericInitialData()
{
  assert( pChem != NULL );
  CellWave::GenericReaction &chem = *pChem; // shorthand
      
  //..set initial data!! --> allow hotspot in p,c,h (xc, yc, width)=exponential
  q= 0.;
  
  for (int igrid=0; igrid< cg.numberOfComponentGrids(); ++igrid) {
    //Index I1, I2,I3;
    //getIndex( cg[igrid].indexRange(), I1,I2,I3);

    MappedGrid & mg = cg[igrid];
    realArray & qArray = q[igrid];
    //realArray & dudtg = dudt[igrid];
    realArray & xArray = mg.vertex();  // array of vertices

    const IntegerArray & d = mg.dimension();
    const IntegerArray & gir= mg.gridIndexRange();
    const int nd   =cg.numberOfDimensions();
    const int ncomp= chem.getNumberOfSpecies();
    double tcomp=0.; //dummy time here

    //..explicit loop here: arguments are the info for a Fortran style loop
    chem.callInitialDataLoop(tcomp, 
			     nd, ncomp,
			     d(0,0),d(1,0),d(0,1),d(1,1),d(0,2),d(1,2), 
			     gir(0,0),gir(1,0),gir(0,1),gir(1,1),gir(0,2),gir(1,2), 
			     *xArray.getDataPointer(),*qArray.getDataPointer() );
 
  }; //end for igrid
  q.periodicUpdate();
  q.interpolate();
}
