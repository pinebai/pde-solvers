
#include "CellWave.h"
#include <stdio.h>
#include <stdarg.h>

namespace CellWave {

void start( int argc, char **argv)
{
  //..initialize debug print facility
  dprintfCreate();
  dprintfSetDefault( PrintOut );

  dprintfOpen(LogPrint,            "OUT/runcellwave.log");
  dprintfOpen(DebugPrint,          "OUT/debug.out");
  dprintfOpen(DetailedDebugPrint,  "OUT/debugDetailed.out");
  dprintfOpen(MinMaxDebugPrint,    "OUT/debugMinMax.out");
  dprintfOpen(DebugReaction,       "OUT/debugReaction.out");
  dprintfOpen(DebugSolver,         "OUT/debugSolver.out");

  dprintf(LogPrint,  "...................CellWave run log............\n");
  dprintf(DebugPrint,"--debug output--\n");
  dprintf(DetailedDebugPrint,"--detailed debug output--\n");
  dprintf(MinMaxDebugPrint,"--Min/Max debug output--\n");
  dprintf(DebugReaction,"-- debug **reactions** output--\n");
  dprintf(DebugSolver,"--debug **solver** output--\n");

}

void finish()
{
  CellWave::dprintfDestruct();
}

}



