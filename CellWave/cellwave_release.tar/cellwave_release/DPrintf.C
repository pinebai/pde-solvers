/// Brief description: debug print facility for CellWave
///
///

#include <stdio.h>
#include <stdarg.h>

namespace CellWave {

# define MAX_DPRINTF_LEVELS 20
# define MAX_DPRINTF_LENGTH 65535
  static int dprintf_default;
  static int dprintf_outputflag[MAX_DPRINTF_LEVELS];
  static FILE* dprintf_file[MAX_DPRINTF_LEVELS];

  void dprintfCreate() {
    int i;
    for ( i=0; i< MAX_DPRINTF_LEVELS; ++i) {
      dprintf_outputflag[i] = 1; /* enabled */
      dprintf_file[i] = stdout;
    }
    dprintf_default = 0;
  }

  void dprintfDestruct() {
    int i;
    for ( i=0; i< MAX_DPRINTF_LEVELS; ++i) {
      FILE*  fp=dprintf_file[i];
      if( fp != stdout ) fclose( fp );
    }
    dprintf_default = -1;
  }

  void dprintfSetDefault( int def_ ) {
    dprintf_default = def_;
  };

  int dprintfOpen( int tag, char *fname )  {
    int ierr;
    FILE *fp;
    
    fp = fopen( fname, "w+");
    ierr = (fp!=0);
    if (ierr != 0 ) dprintf_file[tag] = fp;
    return( ierr );
  }

  void dprintfClose( int dlevel ) {
    if ( ( 0<= dlevel ) && (dlevel < MAX_DPRINTF_LEVELS) ) {
      FILE *fp=dprintf_file[ dlevel ];
      if (fp != stdout ) {
	fclose(fp );
	dprintf_file[ dlevel ] = stdout;
      }
    }
  }

  void dprintfStart( int dlevel ) {
    if ( ( 0<= dlevel ) && (dlevel < MAX_DPRINTF_LEVELS) ) {
      dprintf_outputflag[ dlevel ] = 1;
    }
  }

  void dprintfStop( int dlevel ) {
    if ( ( 0<= dlevel ) && (dlevel < MAX_DPRINTF_LEVELS) ) {
      dprintf_outputflag[ dlevel ] = 0;
    }
  }

  void dprintfStopDebug() {
    int i;
    for ( i=2; i<MAX_DPRINTF_LEVELS; ++i) {
      dprintfStop( i);
    }
  }

  int  dprintfGetStatus( int dlevel ) {
    if ( ( 0<= dlevel ) && (dlevel < MAX_DPRINTF_LEVELS) ){
      return( dprintf_outputflag[ dlevel ] );
    }
  }  

  void dprintf( int dlevel, char *fmt, ...)  {
    va_list ap; /* pointer to each unnamed arg in turn */

    if ( 0 == dprintf_outputflag[ dlevel ] ) return; /* no output */
    
    const int nlenCBuf = MAX_DPRINTF_LENGTH;
    static char cBuf[nlenCBuf];
    
    va_start( ap, fmt);
    vsprintf( cBuf, fmt, ap );
    va_end( ap );

    if ( ( 0<= dlevel ) && (dlevel < MAX_DPRINTF_LEVELS) ) {
      fprintf( dprintf_file[dlevel],"%s", cBuf );
    }
    if (dlevel == 0) {
      int i;
      for ( i =1; i<MAX_DPRINTF_LEVELS; ++i ) {
	if (dprintf_file[i] !=stdout ) {
	  fprintf( dprintf_file[i], "%s", cBuf); /* broadcast to files*/
	}
      } // end for i
    }// end if dlevel==0
  };

}; // end namespace CellWave
