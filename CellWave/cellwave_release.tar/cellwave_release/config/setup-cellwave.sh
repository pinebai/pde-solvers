#
#set environment variables for ftk
#
setenv BOOST /export/0/pfast.0/software/BOOST/boost_1_26_0
setenv CELLWAVE . 

