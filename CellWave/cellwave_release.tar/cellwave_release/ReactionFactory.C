/// Brief description: Factory that creates reaction chem instances
/// 


#include <math.h>
#include <stdio.h>
#include <iostream.h>
#include "GenericReaction.h"

#include "ReactionFactory.h"

//..known reactions
#include "ReactionLiRinzelWagner.h"

using namespace CellWave;

//
// .. constructor
//
ReactionFactory::
ReactionFactory()
{
  //.. do nothing
};

ReactionFactory::
~ReactionFactory()
{
  //.. do nothing
};


GenericReaction* ReactionFactory::
getReaction( const std::string &name) 
{
  //..NEW REACTIONS MUST BE ADDED HERE.
  GenericReaction *pRxn = NULL;
  if      ( name == ReactionLiRinzelWagner::rxnType() ) {
    pRxn = new ReactionLiRinzelWagner();
  } 
  //  else if ( name == ReactionLiRinzelWagner::rxnType() ) {
  // }
  else {
    // throw error
    throw "Reaction Factory error";
  };
} 

